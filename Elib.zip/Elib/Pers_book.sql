select b.id, b.author, b.name,
       f.name, f.id_person, f.id_book
from book b
left join (select p.id, p.name,
                  l.id_person, l.id_book
           from person p
                    left join lending l on (l.id_person = p.id)
           where l.id_person is not null) f on (f.id_book = b.id) where f.id_book is not null;

select b.id, b.author as book_author, b.name as book_name,
       f.name as person_name, f.id_person, f.id_book
from book b
left join (select p.id, p.name,
                  l.id_person, l.id_book
           from person p
                    left join lending l on (l.id_person = p.id)
           where l.id_person is not null) f on (f.id_book = b.id) where f.id_book is not null;

select person.id, person.name,
       lending.id_person, lending.id_book
from person
         left join lending on (lending.id_person = person.id)
where lending.id_person is not null;