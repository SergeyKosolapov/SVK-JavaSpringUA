select p.id, p.name,
       l.id_person, l.id_book
from person p
     left join lending l on (l.id_person = p.id)
where l.id_person is not null
