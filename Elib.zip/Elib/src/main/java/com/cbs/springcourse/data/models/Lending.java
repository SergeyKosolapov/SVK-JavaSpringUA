package com.cbs.springcourse.data.models;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

//http://localhost:8080/lending
//@Entity
//@Table(name = "Lending")
public class Lending {
//    @Id
//    @Column(name = "id")
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Min(value = 0, message = "id_book should be greater than 0")
//    @Column(name = "id_book")
    private int id_book;

    @Min(value = 0, message = "id_person should be greater than 0")
//    @Column(name = "id_person")
    private int id_person;

    @NotEmpty(message = "Person's Name should not be empty")
    @Size(min = 2, max = 100, message = "Person's Name should be between 2 and 100 characters")
//    @Column(name = "name_person")
    private String name_person;

    @NotEmpty(message = "Book's Author should not be empty")
    @Size(min = 2, max = 100, message = "Book's Author should be between 2 and 100 characters")
//    @Column(name = "author_book")
    private String author_book;

    @NotEmpty(message = "Book's Name should not be empty")
    @Size(min = 2, max = 100, message = "Book's Name should be between 2 and 100 characters")
//    @Column(name = "name_book")
    private String name_book;


    public Lending() {

    }

    public Lending(int id_book, int id_person, String name_person, String author_book, String name_book) {
        this.id_book = id_book;
        this.id_person = id_person;
        this.name_person = name_person;
        this.author_book = author_book;
        this.name_book = name_book;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_book() {
        return id_book;
    }

    public void setId_book(int id_book) {
        this.id_book = id_book;
    }

    public int getId_person() {
        return id_person;
    }

    public void setId_person(int id_person) {
        this.id_person = id_person;
    }

    public String getAuthor_book() { return author_book; }

    public void setAuthor_book(String author_book) { this.author_book = author_book;}

    public String getName_book() {return name_book;}

    public void setName_book(String name_book) { this.name_book = name_book;}

    public String getName_person() { return  name_person;}

    public void setName_person(String name_person) { this.name_person = name_person;}


    @Override
    public String toString() {
        return "Lending{" +
                "id=" + id +
                ", id_book='" + id_book + '\'' +
                ", book's author='" + author_book + '\'' +
                ", book's name='" + name_book + '\'' +
                ", id_person=" + id_person + '\'' +
                ", person's name='" + name_person + '\'' +
                '}';
    }
}
