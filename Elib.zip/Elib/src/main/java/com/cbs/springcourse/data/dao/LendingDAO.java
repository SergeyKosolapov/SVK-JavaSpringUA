package com.cbs.springcourse.data.dao;

import com.cbs.springcourse.data.models.Lending;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class LendingDAO {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public LendingDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Lending> index() {
        return jdbcTemplate.query("select b.id, b.author as book_author, b.name as book_name,\n" +
                "       f.name as person_name, f.id_person, f.id_book\n" +
                "from book b\n" +
                "left join (select p.id, p.name,\n" +
                "                  l.id_person, l.id_book\n" +
                "           from person p\n" +
                "                    left join lending l on (l.id_person = p.id)\n" +
                "           where l.id_person is not null) f on (f.id_book = b.id) where f.id_book is not null", new BeanPropertyRowMapper<>(Lending.class));
    }

    public Lending show(int id) {
        return jdbcTemplate.query("select b.id, b.author as book_author, b.name as book_name,\n" +
                        "       f.name as person_name, f.id_person, f.id_book\n" +
                        "from book b\n" +
                        "left join (select p.id, p.name,\n" +
                        "                  l.id_person, l.id_book\n" +
                        "           from person p\n" +
                        "                    left join lending l on (l.id_person = p.id)\n" +
                        "           where l.id_person is not null) f on (f.id_book = b.id) where f.id_book = ?", new Object[]{id}, new BeanPropertyRowMapper<>(Lending.class))
                .stream().findAny().orElse(null);
    }

//  public void save(P p) {
//        jdbcTemplate.update("INSERT INTO Person VALUES(1, ?, ?, ?)", p.getName(), p.getAge(),
//                p.getEmail());
//    }

//    public void update(int id, P updatedP) {
//        jdbcTemplate.update("UPDATE Person SET name=?, age=?, email=? WHERE id=?", updatedP.getName(),
//                updatedP.getAge(), updatedP.getEmail(), id);
//    }

//    public void delete(int id) {
//        jdbcTemplate.update("DELETE FROM Person WHERE id=?", id);
//    }
}
