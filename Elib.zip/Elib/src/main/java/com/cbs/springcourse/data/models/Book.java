package com.cbs.springcourse.data.models;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

//http://localhost:8080/book
//@Entity
//@Table(name = "Book")
public class Book {
//    @Id
//    @Column(name = "id")
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotEmpty(message = "Name should not be empty")
    @Size(min = 2, max = 100, message = "Name should be between 2 and 100 characters")
//    @Column(name = "name")
    private String name;

    @NotEmpty(message = "Author should not be empty")
    @Size(min = 2, max = 100, message = "Author should be between 2 and 100 characters")
//    @Column(name = "author")
    private String author;

    @Min(value = 1900, message = "Year of production should be greater than 1900")
//    @Column(name = "year")
    private int year;

    @Min(value = 0, message = "Availabless should be 0 or 1")
//    @Column(name = "available")
    private int available;

    public Book() {

    }

    public Book(String name, String author, int year, int available) {
        this.name = name;
        this.author = author;
        this.year = year;
        this.available = available;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getYear() { return year;}

    public void setYear(int year) { this.year = year;}

    public int getAvailable() { return available;}

    public void setAvailable(int available) { this.available = available;}

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", author=" + author + '\'' +
                ", year=" + year + '\'' +
                ", available='" + available +
                '}';
    }
}
