package com.cbs.springcourse.data.controllers;

import com.cbs.springcourse.data.dao.LendingDAO;
import com.cbs.springcourse.data.models.Lending;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
@RequestMapping("/lending")
public class LendingController {

    private final LendingDAO lendingDAO;

    @Autowired
    public LendingController(LendingDAO lendingDAO) {
        this.lendingDAO = lendingDAO;
    }

    @GetMapping()
    public String index(Model model) {
        model.addAttribute("lending", lendingDAO.index());
        return "lending/index";
    }

    @GetMapping("/{id}")
    public String show(@PathVariable("id") int id, Model model) {
        model.addAttribute("lending", lendingDAO.show(id));
        return "lending/show";
    }

    @GetMapping("/new")
    public String newLending(@ModelAttribute("lending") Lending lending) {
        return "lending/new";
    }

    @PostMapping()
    public String create(@ModelAttribute("lending") @Valid Lending lending,
                         BindingResult bindingResult) {
        if (bindingResult.hasErrors())
            return "lending/new";

//        lendingDAO.save(lending);
        return "redirect:/lending";
    }

    @GetMapping("/{id}/edit")
    public String edit(Model model, @PathVariable("id") int id) {
        model.addAttribute("lending", lendingDAO.show(id));
        return "lending/edit";
    }

    @PatchMapping("/{id}")
    public String update(@ModelAttribute("person") @Valid Lending lending, BindingResult bindingResult,
                         @PathVariable("id") int id) {
        if (bindingResult.hasErrors())
            return "lending/edit";

//        lendingDAO.update(id, lending);
        return "redirect:/lending";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable("id") int id) {
//        lendingDAO.delete(id);
        return "redirect:/lending";
    }
}
